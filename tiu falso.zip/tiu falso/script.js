// --- Log Inicial y Verificación InteractJS ---
console.log("--- Script Started ---");
if (typeof interact !== 'function') {
    console.error("¡ERROR CRÍTICO: InteractJS no está cargado o no es una función!");
} else {
    console.log("InteractJS Library Loaded: Yes");
}

// --- Listener para Mover (Drag) ---
function dragMoveListener(event) {
    try {
        const target = event.target; // El target del evento es el wrapper
        if (!target || !target.classList.contains('interactive-wrapper')) return; // Ensure target is correct

        // data-x/y store the total offset *from the initial centered position*
        const currentX = parseFloat(target.getAttribute('data-x')) || 0;
        const currentY = parseFloat(target.getAttribute('data-y')) || 0;

        // Calculate the new total offset
        const newX = currentX + event.dx;
        const newY = currentY + event.dy;

        // Apply the transform relative to the initial center (-50%, -50%)
        // We combine the initial centering with the drag offset (newX, newY)
        target.style.transform = `translate(calc(-50% + ${newX}px), calc(-50% + ${newY}px))`;

        // Update the stored offset
        target.setAttribute('data-x', newX);
        target.setAttribute('data-y', newY);

    } catch (error) {
        console.error("Error in dragMoveListener:", error);
    }
}


// --- Ajustar Tamaño Fuente ---
function adjustFontSize(targetId, delta) {
    try {
        const targetElement = document.getElementById(targetId);
        if (!targetElement) { console.warn("adjustFontSize: Target not found:", targetId); return; }
        const style = window.getComputedStyle(targetElement).getPropertyValue('font-size');
        let currentSize = parseFloat(style);
        if (isNaN(currentSize)) currentSize = (targetId === 'time') ? 28.8 : 16; // Fallback based on default rem sizes approx
        let newSize = Math.max(8, Math.min(120, currentSize + delta)); // Limites 8-120px
        targetElement.style.fontSize = newSize + 'px';
    } catch (error) {
        console.error("Error in adjustFontSize:", error);
    }
}

// --- Configurar Interacciones Draggable ---
let interactTimeInstance = null;
let interactDateInstance = null;
function setupDraggableInteractions() {
    console.log("Attempting to setup draggable interactions...");
    if (typeof interact !== 'function') { console.error("Cannot setup interactions: InteractJS not available."); return; }

    // Clean up previous instances if they exist
    if (interactTimeInstance) { try { interactTimeInstance.unset(); } catch(e){ console.warn("Minor error unsetting time interaction:", e); } }
    if (interactDateInstance) { try { interactDateInstance.unset(); } catch(e){ console.warn("Minor error unsetting date interaction:", e); } }
    interactTimeInstance = null;
    interactDateInstance = null;

    const timeWrapper = document.getElementById('time-wrapper');
    const dateWrapper = document.getElementById('date-wrapper');

    if (!timeWrapper) { console.warn("Time wrapper (#time-wrapper) not found for interaction setup."); return; }
    if (!dateWrapper) { console.warn("Date wrapper (#date-wrapper) not found for interaction setup."); return; }

    // Common options for draggable elements
    const commonDraggableOptions = {
        listeners: { move: dragMoveListener },
        inertia: false, // Disable inertia for more direct control, especially on mobile
        // autoScroll: false, // Usually not needed if container isn't scrollable
        // modifiers: [] // No restrictions on movement needed currently
    };

    try {
        // Apply draggable interaction
        interactTimeInstance = interact(timeWrapper).draggable(commonDraggableOptions);
        interactDateInstance = interact(dateWrapper).draggable(commonDraggableOptions);
        console.log("Draggable interactions setup complete.");
    } catch (error) {
        console.error("Error during interact.js setup:", error);
    }
}

// --- Actualizar Hora y Fecha ---
function updateTimeAndDate() {
    try {
        const now = new Date();
        const timeElement = document.getElementById('time');
        const dateElement = document.getElementById('date');

        if (timeElement) {
            const timeOptions = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false };
            timeElement.textContent = new Intl.DateTimeFormat('en-GB', timeOptions).format(now);
        }

        if (dateElement) {
            const dateOptions = { weekday: 'long', day: 'numeric', month: 'short', year: 'numeric' };
            let dateString = new Intl.DateTimeFormat('es-ES', dateOptions).format(now);

            // Format improvements
            dateString = dateString.replaceAll(' de ', ' '); // Remove ' de '
            dateString = dateString.replace(/\.$/, ''); // Remove trailing dot from month (e.g., abr.)
            // Capitalize first letter and month abbreviation
            dateString = dateString.replace(/^\w/, c => c.toUpperCase()).replace(/ (\w{3}) /, (match, p1) => ` ${p1.charAt(0).toUpperCase() + p1.slice(1)} `);
            dateElement.textContent = dateString;
        }
    } catch (error) {
        console.error("Error in updateTimeAndDate:", error);
    }
}
// Start interval
let timeIntervalId = null;
try {
    updateTimeAndDate(); // Initial call
    timeIntervalId = setInterval(updateTimeAndDate, 1000);
    console.log("Time/Date update interval started.");
} catch (error) {
    console.error("Failed to start time/date interval:", error);
}


// --- Cargar Foto ---
function loadPhoto(event) {
    console.log("loadPhoto triggered.");
    try {
        const photoFile = event.target.files[0];
        if (!photoFile || !photoFile.type.startsWith('image/')) {
            alert("Por favor, selecciona un archivo de imagen válido.");
            event.target.value = ''; return;
        }
        const reader = new FileReader();
        reader.onload = function(e) {
            console.log("Photo read success. Updating DOM...");
            const bgImage = document.getElementById('bgImage');
            const imageContainer = document.getElementById('imageContainer');
            const uploadSection = document.getElementById('uploadSection');
            const fullscreenBtn = document.getElementById('fullscreenBtn');
            const timeWrapper = document.getElementById('time-wrapper');
            const dateWrapper = document.getElementById('date-wrapper');
            const timeEl = document.getElementById('time');
            const dateEl = document.getElementById('date');

            if (!bgImage || !imageContainer || !uploadSection || !fullscreenBtn || !timeWrapper || !dateWrapper || !timeEl || !dateEl) {
                 console.error("Critical elements missing before DOM update (loadPhoto).");
                 alert("Error interno al cargar la imagen. Faltan elementos.");
                 return;
            }

            bgImage.src = e.target.result;

            // <<< UPDATED: Reset positions to initial centered state
            timeWrapper.style.top = '45%';
            timeWrapper.style.left = '50%';
            timeWrapper.style.transform = 'translate(-50%, -50%)'; // Reset transform
            timeWrapper.setAttribute('data-x', '0'); // Reset drag offset
            timeWrapper.setAttribute('data-y', '0'); // Reset drag offset

            dateWrapper.style.top = '55%';
            dateWrapper.style.left = '50%';
            dateWrapper.style.transform = 'translate(-50%, -50%)'; // Reset transform
            dateWrapper.setAttribute('data-x', '0'); // Reset drag offset
            dateWrapper.setAttribute('data-y', '0'); // Reset drag offset

            // <<< UPDATED: Reset font sizes (use CSS defaults by removing inline style)
            timeEl.style.fontSize = '';
            dateEl.style.fontSize = '';

            // Show/Hide sections
            imageContainer.style.display = 'block';
            fullscreenBtn.style.display = 'inline-block'; // Show button
            uploadSection.style.display = 'none'; // Hide uploader

            // Setup interactions AFTER elements are visible and positioned
            setupDraggableInteractions();
            console.log("DOM updated and interactions ready.");
        };
        reader.onerror = function(e) { console.error("FileReader error:", e); alert("Error al leer el archivo."); event.target.value = ''; };
        reader.readAsDataURL(photoFile);
    } catch (error) {
        console.error("Error in loadPhoto function:", error);
        alert("Ocurrió un error al procesar la foto.");
    }
}

// --- Fullscreen ---
function toggleFullScreen() {
    console.log("toggleFullScreen called.");
    try {
        const docElement = document.documentElement;

        if (!document.fullscreenElement) {
            console.log("Requesting fullscreen...");
            const requestMethod = docElement.requestFullscreen || docElement.webkitRequestFullscreen || docElement.mozRequestFullScreen || docElement.msRequestFullscreen;
            if (requestMethod) {
                requestMethod.call(docElement).catch(err => {
                    console.error(`Fullscreen request error: ${err.message}`);
                    alert(`No se pudo activar pantalla completa.`);
                    // Ensure classes are removed if entry fails
                    document.documentElement.classList.remove('fullscreen-active');
                    document.body.classList.remove('fullscreen-active');
                });
            } else {
                alert("Tu navegador no soporta la API de Pantalla Completa.");
                console.warn("Fullscreen API not supported by this browser.");
            }
        } else {
            console.log("Exiting fullscreen...");
            const exitMethod = document.exitFullscreen || document.webkitExitFullscreen || document.mozCancelFullScreen || document.msExitFullscreen;
            if (exitMethod) {
                 exitMethod.call(document).catch(err => {
                    console.error(`Fullscreen exit error: ${err.message}`);
                 });
            } else {
                 console.warn("Fullscreen exit API not supported?");
            }
        }
    } catch(error) {
        console.error("Error in toggleFullScreen function:", error);
    }
}

// --- Listener Fullscreen Change ---
try {
    document.addEventListener('fullscreenchange', () => {
        const isFullscreen = !!document.fullscreenElement;
        console.log("Event: fullscreenchange. Is fullscreen?", isFullscreen);
        const htmlElement = document.documentElement;
        const bodyElement = document.body;

        if (isFullscreen) {
            htmlElement.classList.add('fullscreen-active');
            if (bodyElement) bodyElement.classList.add('fullscreen-active');
        } else {
            htmlElement.classList.remove('fullscreen-active');
            if (bodyElement) bodyElement.classList.remove('fullscreen-active');
            // Optional: Re-enable interactions if they were disabled (not done here, but could be)
        }
        console.log("Fullscreen classes updated.");
    });
    console.log("Fullscreen change listener attached.");
} catch (error) {
    console.error("Failed to attach fullscreen listener:", error);
}

console.log("--- Script Setup Finished ---");